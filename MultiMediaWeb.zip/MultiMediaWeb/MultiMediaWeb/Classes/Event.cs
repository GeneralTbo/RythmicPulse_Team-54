﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MultiMedia.Classes
{
    public class Event
    {

        private string name, time, venue, description;

        public string getName()
        {
            return name;
        }

        public string getTime() 
        {
            return time;
        }

        public string getVenue()
        {
            return venue;
        }

        public string Description()
        {
            return description;
        }

        public void setValue(string nam, string tim, string ven, string des)
        {
            name = nam;
            time = tim;
            venue = ven;
            description = des;
        }

        //public void upLoad(FileUpload fi)
        //{
        //    if (fi.HasFile)
        //    {

        //        FileUpload.SaveAs(Server.MapPath("~/Uploads/" + fi.FileName));
        //        lblUpload.Text = "File uploaded";
        //        lblUpload.ForeColor = System.Drawing.Color.Green;
        //        txtReadFile.Text = FileUpload.FileName;



        //    }
        //    else
        //    {
        //        lblUpload.Text = "Please select a file to Upload";
        //        lblUpload.ForeColor = System.Drawing.Color.Red;
        //    }

        //    foreach (String strFile in Directory.GetFiles(Server.MapPath("~/Uploads ")))
        //    {
        //        FileInfo info = new FileInfo(strFile);
        //        if (info.Name.Contains(txtReadFile.Text))
        //        {
        //            showImage.InnerHtml = " <img src=../Uploads/" + txtReadFile.Text + "  height=250 width=350 />";

        //        }


        //    }
        
        //}

        public void createEvent()
        { 
        
        
        }
    }
}