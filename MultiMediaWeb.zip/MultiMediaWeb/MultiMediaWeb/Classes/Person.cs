﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MultiMediaWeb.Classes
{
    public  class Person
    {
        private string name, lastname, email, password, confirm, dateOfBirth, contact, gender;

        public string getName()
        {
            return name;
        }

        public string getLastname()
        {
            return lastname;
        }

        public string getEmail()
        {
            return email;
        }

        public string getPassword()
        {
            return password;
        }

        public string getConfirm()
        {
            return confirm;
        }

        public string getDOB()
        {
            return dateOfBirth;
        }

        public string getContact()
        {
            return contact;
        }

        public string getGender()
        {
            return gender;
        }

        //public void setValue(string name, string lastname, string email, string password, string confirm, string date, string contact, string gender)
        //{ 

        //}
        
    }
}